# AI Research Paper Wizard Backend

Set your API key in `.env` file as `GEMINI_API_KEY`, then run:

```
npm install
npm start
```